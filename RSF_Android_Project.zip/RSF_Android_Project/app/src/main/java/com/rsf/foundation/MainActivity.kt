package com.rsf.foundation

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

private val Black = Color(0xFF101010)
private val Gold = Color(0xFFD6AD54)
private val CardBlack = Color(0xFF1D1D1D)
private val Cream = Color(0xFFF7F0DE)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RSFApp() }
    }
}

@Composable
fun RSFApp() {
    var tab by remember { mutableStateOf("Home") }
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Gold, background = Black, surface = CardBlack,
        onPrimary = Black, onBackground = Cream, onSurface = Cream
    )) {
        Scaffold(
            containerColor = Black,
            topBar = {
                Column(Modifier.fillMaxWidth().background(Black).padding(18.dp)) {
                    Text("RSF", color = Gold, fontSize = 30.sp, fontWeight = FontWeight.Black)
                    Text("RAJPUT STUDENT FOUNDATION", color = Cream, fontSize = 12.sp, letterSpacing = 2.sp)
                }
            },
            bottomBar = {
                NavigationBar(containerColor = CardBlack) {
                    listOf("Home", "Members", "Groups", "News", "Contact").forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            label = { Text(item, fontSize = 10.sp) },
                            icon = {
                                Icon(when(item) {
                                    "Home" -> Icons.Default.Home
                                    "Members" -> Icons.Default.People
                                    "Groups" -> Icons.Default.Chat
                                    "News" -> Icons.Default.Newspaper
                                    else -> Icons.Default.Call
                                }, contentDescription = item)
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Gold, selectedTextColor = Gold,
                                indicatorColor = Color(0xFF3A3020),
                                unselectedIconColor = Cream, unselectedTextColor = Cream
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.padding(padding).fillMaxSize()) {
                when(tab) {
                    "Home" -> HomeScreen()
                    "Members" -> MembersScreen()
                    "Groups" -> GroupsScreen()
                    "News" -> NewsScreen()
                    else -> ContactScreen()
                }
            }
        }
    }
}

@Composable
fun GoldCard(title: String, detail: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier.fillMaxWidth().padding(vertical = 6.dp),
        colors = CardDefaults.cardColors(containerColor = CardBlack),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, color = Gold, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Spacer(Modifier.height(7.dp))
            Text(detail, color = Cream, fontSize = 14.sp, lineHeight = 21.sp)
        }
    }
}

@Composable
fun HomeScreen() {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        item {
            Spacer(Modifier.height(10.dp))
            Text("السلام علیکم", color = Gold, fontSize = 26.sp, fontWeight = FontWeight.Bold,
                textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth())
            Text("Welcome to Rajput Student Foundation", color = Cream, fontSize = 18.sp)
            Spacer(Modifier.height(12.dp))
            GoldCard("آج کا پیغام | Today's Motivation",
                "تعلیم وہ روشنی ہے جو مستقبل کو روشن کرتی ہے۔ محنت جاری رکھیں اور اپنے خوابوں کو حقیقت بنائیں۔")
            GoldCard("RSF Leadership", "Founder: Rana Anas\nRSF Hafizabad: Rana Noman\nRSF Qila Mir Zaman: Rana Anas")
            GoldCard("Latest Announcement", "RSF کی تازہ خبریں، میٹنگز اور کمیونٹی سرگرمیوں کے لیے اس سیکشن کو دیکھیں۔")
            GoldCard("Our Mission", "طلبہ کی رہنمائی، تعلیم کی ترویج، اور مثبت کمیونٹی سرگرمیوں کے ذریعے ایک روشن مستقبل۔")
        }
    }
}

@Composable
fun MembersScreen() {
    var search by remember { mutableStateOf("") }
    val members = listOf(
        "Rana Anas" to "Founder • Qila Mir Zaman",
        "Rana Noman" to "RSF Hafizabad",
        "RSF Member" to "Member profile pending"
    ).filter { it.first.contains(search, ignoreCase = true) || it.second.contains(search, ignoreCase = true) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("RSF Members", color = Gold, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(value = search, onValueChange = { search = it }, label = { Text("Search members") },
            modifier = Modifier.fillMaxWidth(), singleLine = true)
        LazyColumn {
            items(members) { member ->
                GoldCard(member.first, member.second + "\nContact number: hidden until permission is granted")
            }
        }
    }
}

@Composable
fun GroupsScreen() {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("RSF Groups", color = Gold, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        GoldCard("RSF Hafizabad", "Group announcements and member discussion. Online chat activates after Firebase setup.")
        GoldCard("RSF Qila Mir Zaman", "Community updates and student communication. Online chat activates after Firebase setup.")
        Text("Note: Group messaging requires authenticated Firebase users and secure Firestore rules.", color = Cream, fontSize = 12.sp)
    }
}

@Composable
fun NewsScreen() {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp)) {
        item {
            Text("RSF News & Activities", color = Gold, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            GoldCard("Community Activities", "Meeting updates, educational events, and community service announcements will appear here.")
            GoldCard("Publish News", "Admin publishing tools connect after Firebase configuration and admin role setup.")
        }
    }
}

@Composable
fun ContactScreen() {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Contact RSF", color = Gold, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        GoldCard("Foundation", "Rajput Student Foundation (RSF)\nFounder: Rana Anas")
        GoldCard("Regional Contacts", "RSF Hafizabad • Rana Noman\nRSF Qila Mir Zaman • Rana Anas")
        GoldCard("Contact & Social", "Add official WhatsApp number and social media URLs in the project configuration before release.")
    }
}
