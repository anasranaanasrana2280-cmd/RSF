# Rajput Student Foundation (RSF) — Android starter project

Premium black-and-gold Android application starter using Kotlin, Jetpack Compose, and Firebase SDKs.

## Included
- RSF branded Home, Members, Groups, News, and Contact sections
- Basic member search and Urdu-friendly text layout
- Firebase Auth, Firestore, and Storage dependencies included
- Android project source suitable for Android Studio

## Important: deployment setup is still required
This starter is not yet a production-ready APK. Online registration, shared group chat, admin authorization, uploads, and publishing need Firebase project configuration and implementation/testing.

### Configure Firebase
1. Create a project at https://console.firebase.google.com/
2. Add Android app package `com.rsf.foundation`.
3. Download `google-services.json` and place it in `app/`.
4. Enable Authentication (Email/Password), Firestore Database, and Storage.
5. Configure Firestore and Storage security rules. Never use open production rules.
6. Add real RSF phone/social URLs and admin accounts.

### Build APK
1. Open this folder in Android Studio (current stable).
2. Install Android SDK 35 and JDK 17.
3. Sync Gradle.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install the generated APK on a test phone and validate all flows.

## Suggested production collections
- `users/{uid}`: displayName, city, designation, photoURL, role
- `groups/{groupId}`: name, region, memberUIDs
- `groups/{groupId}/messages/{messageId}`: senderUID, text, createdAt
- `announcements/{announcementId}`: title, body, mediaURL, publishedAt, authorUID
- `dailyMessages/{yyyy-MM-dd}`: text, language

Admin roles must be validated in trusted Firestore rules (prefer custom claims); do not rely only on hiding admin buttons in the app. Member phone numbers should be in a restricted document or access-controlled field and only read by authorized users.

## Build note
The environment that generated this project did not have Android SDK/Gradle installed, so an APK could not be compiled here. This is the Android Studio source project, not a fabricated APK.
